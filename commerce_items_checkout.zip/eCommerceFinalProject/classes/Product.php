<?php
declare(strict_types=1);

/*
 * eCommerceFinalProject Product.php
 * 
 * @author Ying-Shan Liang (Celine Liang)
 * @since 2023-04-29
 * (c) Copyright 2023 Ying-Shan Liang 
 */

namespace classes;

/**
 * @TODO   Documentation
 *
 * @author Ying-Shan Liang
 * @since  2023-04-29
 */
class Product {
    
    public string $id;
    public string $description;
    public string $image_url;
    public string $unit_price;
    public string $available_quantity;
    public string $date_created;
    
    public function __construct($id, $description, $image_url, $unit_price, $available_quantity, $date_created) {
        $this->id = $id;
        $this->description = $description;
        $this->image_url = $image_url;
        $this->unit_price = $unit_price;
        $this->available_quantity = $available_quantity;
        $this->date_created = $date_created;
    }
    
    /**
     * @return string
     */
    public function getId() : string {
        return $this->id;
    }
    
    /**
     * @param string $id
     */
    public function setId(string $id) : void {
        $this->id = $id;
    }
    
    /**
     * @return string
     */
    public function getDescription() : string {
        return $this->description;
    }
    
    /**
     * @param string $description
     */
    public function setDescription(string $description) : void {
        $this->description = $description;
    }
    
    /**
     * @return string
     */
    public function getImageUrl() : string {
        return $this->image_url;
    }
    
    /**
     * @param string $image_url
     */
    public function setImageUrl(string $image_url) : void {
        $this->image_url = $image_url;
    }
    
    /**
     * @return string
     */
    public function getUnitPrice() : string {
        return $this->unit_price;
    }
    
    /**
     * @param string $unit_price
     */
    public function setUnitPrice(string $unit_price) : void {
        $this->unit_price = $unit_price;
    }
    
    /**
     * @return string
     */
    public function getAvailableQuantity() : string {
        return $this->available_quantity;
    }
    
    /**
     * @param string $available_quantity
     */
    public function setAvailableQuantity(string $available_quantity) : void {
        $this->available_quantity = $available_quantity;
    }
    
    /**
     * @return string
     */
    public function getDateCreated() : string {
        return $this->date_created;
    }
    
    /**
     * @param string $date_created
     */
    public function setDateCreated(string $date_created) : void {
        $this->date_created = $date_created;
    }
    
    
    
    
}
    
