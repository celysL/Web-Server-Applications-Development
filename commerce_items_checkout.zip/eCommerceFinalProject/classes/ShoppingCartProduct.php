<?php
declare(strict_types=1);

/*
 * eCommerceFinalProject ShoppingCartProduct.php
 * 
 * @author Ying-Shan Liang (Celine Liang)
 * @since 2023-04-29
 * (c) Copyright 2023 Ying-Shan Liang 
 */

namespace classes;

/**
 * @TODO   Documentation
 *
 * @author Ying-Shan Liang
 * @since  2023-04-29
 */
class ShoppingCartProduct {
    private string $shopping_cart_id;
    private string $product_id;
    private string $quantity;
    
    public function __construct($shopping_cart_id, $product_id, $quantity) {
        $this->shopping_cart_id = $shopping_cart_id;
        $this->product_id = $product_id;
        $this->quantity = $quantity;
    }
    
    /**
     * @return string
     */
    public function getShoppingCartId() : string {
        return $this->shopping_cart_id;
    }
    
    /**
     * @param string $shopping_cart_id
     */
    public function setShoppingCartId(string $shopping_cart_id) : void {
        $this->shopping_cart_id = $shopping_cart_id;
    }
    
    /**
     * @return string
     */
    public function getProductId() : string {
        return $this->product_id;
    }
    
    /**
     * @param string $product_id
     */
    public function setProductId(string $product_id) : void {
        $this->product_id = $product_id;
    }
    
    /**
     * @return string
     */
    public function getQuantity() : string {
        return $this->quantity;
    }
    
    /**
     * @param string $quantity
     */
    public function setQuantity(string $quantity) : void {
        $this->quantity = $quantity;
    }
    
}