<?php
declare(strict_types=1);

/*
 * eCommerceFinalProject ShoppingCart.php
 * 
 * @author Ying-Shan Liang (Celine Liang)
 * @since 2023-04-29
 * (c) Copyright 2023 Ying-Shan Liang 
 */

namespace classes;

/**
 * @TODO   Documentation
 *
 * @author Ying-Shan Liang
 * @since  2023-04-29
 */
class ShoppingCart {
    private string $id;
    private string $status;
    private string $quantity;
    
    public function __construct($id, $status, $quantity) {
        $this->id = $id;
        $this->status = $status;
        $this->quantity = $quantity;
    }
    
    /**
     * @return string
     */
    public function getId() : string {
        return $this->id;
    }
    
    /**
     * @param string $id
     */
    public function setId(string $id) : void {
        $this->id = $id;
    }
    
    /**
     * @return string
     */
    public function getStatus() : string {
        return $this->status;
    }
    
    /**
     * @param string $status
     */
    public function setStatus(string $status) : void {
        $this->status = $status;
    }
    
    /**
     * @return string
     */
    public function getQuantity() : string {
        return $this->quantity;
    }
    
    /**
     * @param string $quantity
     */
    public function setQuantity(string $quantity) : void {
        $this->quantity = $quantity;
    }
    
    
}