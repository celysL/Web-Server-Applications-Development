<?php
declare(strict_types=1);

/*
 * finalProjectCommerce login.php
 * 
 * @author Ying-Shan Liang (Celine Liang)
 * @since 2023-04-28
 * (c) Copyright 2023 Ying-Shan Liang 
 */

include 'include/config.php';
include 'classes/UserLogin.php';
session_start();

/**
 * @TODO   Documentation
 *
 * @author Ying-Shan Liang
 * @since  2023-04-29
 */
//class User {
//    private string $name;
//    private string $password;
//
//    /**
//     * @param $name
//     * @param $password
//     */
//    public function __construct($name, $password) {
//        $this->name = $name;
//        $this->password = md5($password);
//    }
//
//    /**
//     * @return bool|void
//     *
//     * @author Ying-Shan Liang
//     * @since  2023-04-29
//     */
//    public function authenticateUser() {
//        global $conn;
//
//        $name = mysqli_real_escape_string($conn, $this->name);
//        $password = mysqli_real_escape_string($conn, $this->password);
//
//        $select = mysqli_query($conn, "select * from `customer` where username = '$name' and password = '$password'") or die('Query failed');
//
//        if(mysqli_num_rows($select) > 0) {
//            $row = mysqli_fetch_assoc($select);
//            $_SESSION['user_id'] = $row['id'];
//
//            // Set cookies
//            setcookie('user_name', $name, time() + 60 * 60 * 24 * 30); // 30 days
//            setcookie('user_pass', $password, time() + 60 * 60 * 24 * 30); // 30 days
//
//            return true;
//        }
//        else {
//            return false;
//        }
//    }
//}

if(isset($_POST['submit'])) {
    $name = $_POST['name'];
    $password = $_POST['password'];
    
    $user = new UserLogin($name, $password);
    
    if ($user->authenticateUser()) {
        header('Location: index.php');
        exit();
    }
    else {
        $message[] = 'Incorrect username or password';
    }
}
//if(isset($_POST['submit'])) {
//    $name = mysqli_real_escape_string($conn, $_POST['name']);
//    $pass = mysqli_real_escape_string($conn, md5($_POST['password']));
//
//    $select = mysqli_query($conn, "select * from `customer` where username = '$name' and password = '$pass'") or die('query failed');
//
//    if(mysqli_num_rows($select) > 0){
//        $row = mysqli_fetch_assoc($select);
//        $_SESSION['user_id'] = $row['id'];
//        header('location: index.php');
//    }
//    else{
//        $message[] = 'incorrect username or password';
//    }
//}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    
    <link rel="stylesheet" href="css/login.css">

</head>
<body>

<?php

if(isset($message)){
    foreach ($message as $message){
        echo '<div class="message" onclick="this.remove();">'.$message.'</div>';
    }
}

?>

<div class="form-container">
    <form action="" method="post">
        <h3>Login now</h3>
        <input type="text" name="name" required placeholder="username" class="box" value="<?php echo isset($_COOKIE['user_name']) ? $_COOKIE['user_name'] : ''; ?>">
        <input type="password" name="password" required placeholder="password" class="box" value="<?php echo isset($_COOKIE['user_pass']) ? $_COOKIE['user_pass'] : ''; ?>">
        <input type="checkbox" name="remember_me" id="remember_me" <?php if(isset($_COOKIE['user_name'])) echo "checked"; ?>>
        <label for="remember_me">Remember me</label>
        <input type="submit" name="submit" class="btn" value="login now" >
        
        <p>don't have an account? <a href="register.php">Register now</a> </p>
    
    </form>
</div>
</body>
</html>