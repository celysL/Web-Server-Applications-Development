<?php
declare(strict_types=1);

/*
 * finalProjectCommerce show_cart.php
 * 
 * @author Ying-Shan Liang (Celine Liang)
 * @since 2023-04-29
 * (c) Copyright 2023 Ying-Shan Liang 
 */
include 'include/config.php';

$query = "select * from product";
$res = mysqli_query($conn, $query);
$output = " ";

if(mysqli_num_rows($res) < 1){
    $output .= "No Item";
}

    while($row = mysqli_fetch_array($res)){
        $output .= "<div class='col-md-4 shadowm-sm mx-1'>
        <img src='".$row['image url']."' style='height:150px'>
        <h5>".$row['display name']."</h5>
        <h5>$".$row['unit price']."</h5>
        <input type='hidden' name='price' id='price' >
        <input type='hidden' name='name' id='name' >
        <input type='number' name='quantity' id='quantity' class='form-control' value='1'>
        
        <input type='submit' name='add_to_cart' class='btn btn-warning' value='Add To Cart' id='".$row['id']."'>
        </div>";
    }
echo $output;


?>

