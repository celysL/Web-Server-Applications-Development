<?php
declare(strict_types=1);

/*
 * finalProjectCommerce header.php
 * 
 * @author Ying-Shan Liang (Celine Liang)
 * @since 2023-04-29
 * (c) Copyright 2023 Ying-Shan Liang 
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title></title>
    <link rel="stylesheet" href="/css/register.css"> 
</head>
<body>
<nav class="navbar">
    <a href="#" class="logo">DAESAN</a>
    <input type="checkbox" id="toggler">
    <label for="togger"><i class="ri-menu-line"></i></label>
    <div class="menu">
        <ul class="list">
            <li><a href="/index.php">Home</a></li>
            <li><a href="/cart.php"></a>Cart</li>
        </ul>
    </div>
</nav>

</body>

 </html>