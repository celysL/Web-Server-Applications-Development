<?php
declare(strict_types=1);

/*
 * finalProjectCommerce ${FILE_NAME}
 * 
 * @author Ying-Shan Liang (Celine Liang)
 * @since 2023-04-29
 * (c) Copyright 2023 Ying-Shan Liang 
 */