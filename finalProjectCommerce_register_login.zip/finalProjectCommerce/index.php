<?php
declare(strict_types=1);

/*
 * finalProjectCommerce index.php
 * 
 * @author Ying-Shan Liang (Celine Liang)
 * @since 2023-04-28
 * (c) Copyright 2023 Ying-Shan Liang 
 */
?>
<?php
include 'include/config.php';
//session_start();
//$user_id = $_SESSION['user_id'];
//
//if(!isset($user_id)){
//    header('location:login.php');
//};
//
//if(isset($_GET['logout'])){
//    unset($user_id);
//    session_destroy();
//    header('location:login.php');
//};
//
//if(isset($_POST['add_to_cart'])){
//
//    $product_name = $_POST['product_name'];
//    $product_price = $_POST['product_price'];
//    $product_image = $_POST['product_image'];
//    $product_quantity = $_POST['product_quantity'];
//
//    $select_cart = mysqli_query($conn, "select * from `shopping cart` where `display name` = '$product_name' and id = '$user_id'") or die('query failed');
//
//    if(mysqli_num_rows($select_cart) > 0){
//        $message[] = 'product already added to cart!';
//    }else{
//        mysqli_query($conn, "insert into `shopping cart`(id, name, price, image, quantity) VALUES('$user_id', '$product_name', '$product_price', '$product_image', '$product_quantity')") or die('query failed');
//        $message[] = 'product added to cart!';
//    }
//
//};
//
//if(isset($_POST['update_cart'])){
//    $update_quantity = $_POST['cart_quantity'];
//    $update_id = $_POST['cart_id'];
//    mysqli_query($conn, "UPDATE `cart` SET quantity = '$update_quantity' WHERE id = '$update_id'") or die('query failed');
//    $message[] = 'cart quantity updated successfully!';
//}
//
//if(isset($_GET['remove'])){
//    $remove_id = $_GET['remove'];
//    mysqli_query($conn, "DELETE FROM `cart` WHERE id = '$remove_id'") or die('query failed');
//    header('location:index.php');
//}
//
//if(isset($_GET['delete_all'])){
//    mysqli_query($conn, "DELETE FROM `cart` WHERE user_id = '$user_id'") or die('query failed');
//    header('location:index.php');
//}

?>
<!---->
<!--<!DOCTYPE html>-->
<!--<html lang="en">-->
<!--<head>-->
<!--    <meta charset="UTF-8" />-->
<!--    <meta http-equiv="X-UA-Compatible" content="IE=edge">-->
<!--    <meta name="viewport" content="width=device-width, initial-scale=1.0">-->
<!--    <title>CELINE'S SHOP</title>-->
<!--    -->
<!--    <link rel="stylesheet" href="css/style.css">-->
<!---->
<!--</head>-->
<!---->
<!--<body>-->
<!---->
<?php
//if(isset($message)){
//    foreach($message as $message){
//        echo '<div class="message" onclick="this.remove();">'.$message.'</div>';
//    }
//}
//?>
<!---->
<!--<div class="container">-->
<!--    -->
<!--    <div class="user-profile">-->
<!--        -->
<!--        --><?php
//        $select_user = mysqli_query($conn, "select * from `customer` where id = '$user_id'") or die('query failed');
//        if(mysqli_num_rows($select_user) > 0){
//            $fetch_user = mysqli_fetch_assoc($select_user);
//        };
//        ?>
<!--        -->
<!--        <p> username : <span>--><?php //echo $fetch_user['username']; ?><!--</span> </p>-->
<!--        <p> email : <span>--><?php //echo $fetch_user['email']; ?><!--</span> </p>-->
<!--        <div class="flex">-->
<!--            <a href="login.php" class="btn">login</a>-->
<!--            <a href="register.php" class="option-btn">register</a>-->
<!--            <a href="index.php?logout=--><?php //echo $user_id; ?><!--" onclick="return confirm('are your sure you want to logout?');" class="delete-btn">logout</a>-->
<!--        </div>-->
<!--    -->
<!--    </div>-->
<!--    -->
<!--    <div class="products">-->
<!--        -->
<!--        <h1 class="heading">latest products</h1>-->
<!--        -->
<!--        <div class="box-container">-->
<!--            -->
<!--            --><?php
//            $select_product = mysqli_query($conn, "select * from `product`") or die('query failed');
//            if(mysqli_num_rows($select_product) > 0){
//                while($fetch_product = mysqli_fetch_assoc($select_product)){
//                    ?>
<!--                    <form method="post" class="box" action="">-->
<!--                        <img src="images/--><?php //echo $fetch_product['image url']; ?><!--" alt="">-->
<!--                        <div class="name">--><?php //echo $fetch_product['display name']; ?><!--</div>-->
<!--                        <div class="price">$--><?php //echo $fetch_product['unit price']; ?><!--/-</div>-->
<!--                        <input type="number" min="1" name="product_quantity" value="1">-->
<!--                        <input type="hidden" name="product_image" value="--><?php //echo $fetch_product['image url']; ?><!--">-->
<!--                        <input type="hidden" name="product_name" value="--><?php //echo $fetch_product['display name']; ?><!--">-->
<!--                        <input type="hidden" name="product_price" value="--><?php //echo $fetch_product['unit price']; ?><!--">-->
<!--                        <input type="submit" value="add to cart" name="add_to_cart" class="btn">-->
<!--                    </form>-->
<!--                    --><?php
//                };
//            };
//            ?>
<!--        -->
<!--        </div>-->
<!--    -->
<!--    </div>-->
<!--    -->
<!--    <div class="shopping-cart">-->
<!--        -->
<!--        <h1 class="heading">shopping cart</h1>-->
<!--        -->
<!--        <table>-->
<!--            <thead>-->
<!--            <th>image</th>-->
<!--            <th>name</th>-->
<!--            <th>price</th>-->
<!--            <th>quantity</th>-->
<!--            <th>total price</th>-->
<!--            <th>action</th>-->
<!--            </thead>-->
<!--            <tbody>-->
<!--            --><?php
//            $cart_query = mysqli_query($conn, "SELECT * FROM `shopping cart` WHERE id = '$user_id'") or die('query failed');
//            $grand_total = 0;
//            if(mysqli_num_rows($cart_query) > 0){
//                while($fetch_cart = mysqli_fetch_assoc($cart_query)){
//                    ?>
<!--                    <tr>-->
<!--                        <td><img src="img/--><?php //echo $fetch_cart['image url']; ?><!--" height="100" alt=""></td>-->
<!--                        <td>--><?php //echo $fetch_cart['name']; ?><!--</td>-->
<!--                        <td>$--><?php //echo $fetch_cart['price']; ?><!--/-</td>-->
<!--                        <td>-->
<!--                            <form action="" method="post">-->
<!--                                <input type="hidden" name="cart_id" value="--><?php //echo $fetch_cart['id']; ?><!--">-->
<!--                                <input type="number" min="1" name="cart_quantity" value="--><?php //echo $fetch_cart['quantity']; ?><!--">-->
<!--                                <input type="submit" name="update_cart" value="update" class="option-btn">-->
<!--                            </form>-->
<!--                        </td>-->
<!--                        <td>$--><?php //echo $sub_total = ($fetch_cart['unit price'] * $fetch_cart['quantity']); ?><!--/-</td>-->
<!--                        <td><a href="index.php?remove=--><?php //echo $fetch_cart['id']; ?><!--" class="delete-btn" onclick="return confirm('remove item from cart?');">remove</a></td>-->
<!--                    </tr>-->
<!--                    --><?php
//                    $grand_total += $sub_total;
//                }
//            }else{
//                echo '<tr><td style="padding:20px; text-transform:capitalize;" colspan="6">no item added</td></tr>';
//            }
//            ?>
<!--            <tr class="table-bottom">-->
<!--                <td colspan="4">grand total :</td>-->
<!--                <td>$--><?php //echo $grand_total; ?><!--/-</td>-->
<!--                <td><a href="index.php?delete_all" onclick="return confirm('delete all from shopping cart?');" class="delete-btn --><?php //echo ($grand_total > 1)?'':'disabled'; ?><!--">delete all</a></td>-->
<!--            </tr>-->
<!--            </tbody>-->
<!--        </table>-->
<!--        -->
<!--        <div class="cart-btn">-->
<!--            <a href="#" class="btn --><?php //echo ($grand_total > 1)?'':'disabled'; ?><!--">proceed to checkout</a>-->
<!--        </div>-->
<!--    -->
<!--    </div>-->
<!---->
<!--</div>-->
<!---->
<!--</body>-->
<!--</html>-->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DAESAN</title>
    <!--  bootstrap cdn  -->
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <!-- Optional theme -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    
    <link rel="stylesheet" href="css/style.css">

</head>
<body>
    
    <?php include 'include/header.php';?>

    <div class="container">
        <div class="col-md-12">
            <div class="row show_cart">
            
            </div>
            
        </div>
        
    </div>

<!-- jquery cdn -->
<script src="https://code.jquery.com/jquery-3.6.4.js" integrity="sha256-a9jBBRygX1Bh5lt8GZjXDzyOB+bWve9EiO7tROUtj/E=" crossorigin="anonymous"></script>

<script type="text/javascript">
   function show_cart(){
       $.ajax({
           method: "POST",
           url:"show_cart.php",
           success:function(data){
                $(".show_cart").html(data);
           }
       });
   }
    
</script>
</body>
</html>
