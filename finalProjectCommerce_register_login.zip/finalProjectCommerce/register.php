<?php

/*
 * finalProjectCommerce register.php
 *
 * @author Ying-Shan Liang (Celine Liang)
 * @since 2023-04-28
 * (c) Copyright 2023 Ying-Shan Liang
 */

//include 'config.php';
//
//if(isset($_POST['submit'])) {
//    $name = mysqli_real_escape_string($conn, $_POST['name']);
//    $email = mysqli_real_escape_string($conn, $_POST['email']);
//    $pass = mysqli_real_escape_string($conn, md5($_POST['password']));
//    $cpass = mysqli_real_escape_string($conn, md5($_POST['cpassword']));
//
//    $select = mysqli_query($conn, "select * from `customer` where email = '$email' and password = '$pass'") or die('query failed');
//
//    if(mysqli_num_rows($select) > 0){
//        $message[] = 'user already exists';
//    }
//    else{
//        mysqli_query($conn, "insert into `customer`(username, password, email) values ('$name', '$pass', '$email')") or die('query failed');
//        $message[] = 'registered successfully!';
//        header('location: login.php');
//    }
//}

include 'include/config.php';
include 'classes/UserRegistration.php';

/**
 * @TODO   Documentation
 *
 * @author Ying-Shan Liang
 * @since  2023-04-29
 */
//class User {
//    private string $name;
//    private string $email;
//    private string $password;
//
//    /**
//     * @param $name
//     * @param $email
//     * @param $password
//     */
//    public function __construct($name, $email, $password) {
//        $this->name = $name;
//        $this->email = $email;
//        $this->password = md5($password);
//    }
//
//    /**
//     * @return array|void
//     *
//     * @author Ying-Shan Liang
//     * @since  2023-04-29
//     */
//    public function registerUser() {
//        global $conn;
//
//        $name = mysqli_real_escape_string($conn, $this->name);
//        $email = mysqli_real_escape_string($conn, $this->email);
//        $password = mysqli_real_escape_string($conn, $this->password);
//
//        $select = mysqli_query($conn, "select * from `customer` where email = '$email' and password = '$password'") or die('Query failed');
//
//        if(mysqli_num_rows($select) > 0) {
//            $message[] = 'User already exists';
//            return $message;
//        }
//        else {
//            mysqli_query($conn, "insert into `customer`(username, password, email) values ('$name', '$password', '$email')") or die('Query failed');
//            $message[] = 'Registered successfully!';
//            return $message;
//        }
//    }
//}

if(isset($_POST['submit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];
    
    if ($password != $cpassword) {
        $message[] = 'Passwords do not match!';
    }
    else {
        $user = new UserRegistration($name, $email, $password);
        $message = $user->registerUser();
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    
    <link rel="stylesheet" href="css/register.css">
    
</head>
<body>

<?php

if(isset($message)){
    foreach ($message as $message){
        echo '<div class="message" onclick="this.remove();">'.$message.'</div>';
    }
}

?>

<div class="form-container">
    <form action="" method="post">
        <h3>Register now</h3>
        <input type="text" name="name" required placeholder="username" class="box">
        <input type="email" name="email" required placeholder="email" class="box">
        <input type="password" name="password" required placeholder="password" class="box">
        <input type="password" name="cpassword" required placeholder="confirm password" class="box"><!--    password confirmation    -->
        <input type="submit" name="submit" class="btn" value="register now" >
        
        <p>already have an account? <a href="login.php">login now</a> </p>
        
    </form>
</div>
</body>
</html>